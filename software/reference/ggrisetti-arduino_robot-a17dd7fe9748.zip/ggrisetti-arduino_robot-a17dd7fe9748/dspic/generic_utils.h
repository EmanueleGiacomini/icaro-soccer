/* 
 * File:   genericUtils.h
 * Author: malcom
 *
 * Created on June 12, 2013, 12:56 PM
 */

#pragma once

#ifdef __cplusplus 
extern "C" {
#endif

void toggleLed1();
void toggleLed2();
void DelayN10us(int );
void DelayN1ms(int );
void DelayN1s(int );

#ifdef __cplusplus 
}
#endif

